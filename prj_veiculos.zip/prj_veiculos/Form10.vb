﻿Public Class Form10
    Private Sub Form10_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MontarGrid()
        cmb_filtro.Items.Add("CNH")
        cmb_filtro.Items.Add("Nome")
        cmb_filtro.Items.Add("Email")
        cmb_filtro.SelectedIndex = 0
        carregar_clientes()

    End Sub

    Private Sub MontarGrid()
        ' monta as colunas (chama só uma vez)
        dgv_dados.Columns.Clear()

        dgv_dados.Columns.Add("cnh", "CNH")
        dgv_dados.Columns.Add("nome", "Nome")
        dgv_dados.Columns.Add("email", "Email")
        dgv_dados.Columns.Add("senha", "Senha")
        dgv_dados.Columns.Add("status", "Status")

        Dim colBloquear As New DataGridViewButtonColumn()
        colBloquear.Name = "btn_bloquear"
        colBloquear.HeaderText = "Bloquear/Ativar"
        colBloquear.Text = "Bloquear/Ativar"
        colBloquear.UseColumnTextForButtonValue = True
        dgv_dados.Columns.Add(colBloquear)

        Dim colExcluir As New DataGridViewButtonColumn()
        colExcluir.Name = "btn_excluir"
        colExcluir.HeaderText = "Excluir"
        colExcluir.Text = "Excluir"
        colExcluir.UseColumnTextForButtonValue = True
        dgv_dados.Columns.Add(colExcluir)

        ' Configurações visuais
        dgv_dados.AllowUserToAddRows = False
        dgv_dados.ReadOnly = False
        dgv_dados.Columns("cnh").ReadOnly = True
        dgv_dados.Columns("nome").ReadOnly = True
        dgv_dados.Columns("email").ReadOnly = True
        dgv_dados.Columns("senha").ReadOnly = True
        dgv_dados.Columns("status").ReadOnly = True
    End Sub
    Private Sub carregar_clientes()
        Try
            dgv_dados.Rows.Clear()

            sql = "SELECT cnh, nome, email, senha, status FROM clientes"
            rs = db.Execute(sql)

            Do While Not rs.EOF
                dgv_dados.Rows.Add(
                    rs.Fields("cnh").Value.ToString(),
                    rs.Fields("nome").Value.ToString(),
                    rs.Fields("email").Value.ToString(),
                    rs.Fields("senha").Value.ToString(),
                    rs.Fields("status").Value.ToString()
                )
                rs.MoveNext()
            Loop

        Catch ex As Exception
            MsgBox("Erro ao carregar clientes: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try

        Try
            sql = "SELECT cnh, nome, email, senha, status FROM clientes"
            rs = db.Execute(sql)

            dgv_dados.Rows.Clear()
            Do Until rs.EOF
                dgv_dados.Rows.Add(
                    rs.Fields("cnh").Value,
                    rs.Fields("nome").Value,
                    rs.Fields("email").Value,
                    rs.Fields("senha").Value,
                    rs.Fields("status").Value
                )
                rs.MoveNext()
            Loop

        Catch ex As Exception
            MsgBox("Erro ao carregar clientes: " & ex.Message)
        End Try
    End Sub

    Private Sub dgv_dados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados.CellContentClick
        Try
            If e.RowIndex < 0 Then Exit Sub

            Dim cnhCliente As String = dgv_dados.Rows(e.RowIndex).Cells("cnh").Value.ToString()

            ' índice das colunas criadas:
            ' 0=cnh, 1=nome, 2=email, 3=senha, 4=status, 5=btn_bloquear, 6=btn_excluir

            If e.ColumnIndex = dgv_dados.Columns("btn_bloquear").Index Then
                sql = "SELECT status FROM clientes WHERE cnh='" & cnhCliente.Replace("'", "''") & "'"
                rs = db.Execute(sql)
                If Not rs.EOF Then
                    Dim statusAtual As String = rs.Fields("status").Value.ToString()
                    Dim novoStatus As String = If(statusAtual.ToLower() = "ativo", "bloqueado", "ativo")

                    sql = "UPDATE clientes SET status='" & novoStatus & "' WHERE cnh='" & cnhCliente.Replace("'", "''") & "'"
                    db.Execute(sql)

                    MsgBox("Status do cliente atualizado para '" & novoStatus & "'.", MsgBoxStyle.Information, "Sucesso")
                    carregar_clientes()
                End If
                Exit Sub
            End If

            If e.ColumnIndex = dgv_dados.Columns("btn_excluir").Index Then
                If MsgBox("Deseja realmente excluir este cliente? Esta ação é irreversível.", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmação") = MsgBoxResult.Yes Then
                    sql = "DELETE FROM clientes WHERE cnh='" & cnhCliente.Replace("'", "''") & "'"
                    db.Execute(sql)
                    MsgBox("Cliente excluído com sucesso!", MsgBoxStyle.Information, "Aviso")
                    carregar_clientes()
                End If
                Exit Sub
            End If

        Catch ex As Exception
            MsgBox("Erro ao executar ação: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    Private Sub txt_pesquisa_TextChanged(sender As Object, e As EventArgs) Handles txt_pesquisa.TextChanged
        Try
            Dim filtro As String = cmb_filtro.Text
            Dim valor As String = txt_pesquisa.Text.Trim()

            sql = "SELECT cnh, nome, email, senha, status FROM clientes " &
                  "WHERE " & filtro & " LIKE '%" & valor & "%'"

            rs = db.Execute(sql)

            dgv_dados.Rows.Clear()
            Do Until rs.EOF
                dgv_dados.Rows.Add(
                    rs.Fields("cnh").Value,
                    rs.Fields("nome").Value,
                    rs.Fields("email").Value,
                    rs.Fields("senha").Value,
                    rs.Fields("status").Value
                )
                rs.MoveNext()
            Loop

        Catch ex As Exception
            MsgBox("Erro ao filtrar: " & ex.Message)
        End Try
    End Sub

    Private Sub cmb_filtro_Click(sender As Object, e As EventArgs) Handles cmb_filtro.Click

    End Sub
End Class