﻿Public Class Form5
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub btn_gravar_Click(sender As Object, e As EventArgs) Handles btn_gravar.Click
        If txt_senha.Text <> txt_csenha.Text Then
            MsgBox("As senhas não coincidem.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Erro")
            txt_senha.Clear()
            txt_csenha.Clear()
            txt_senha.Focus()
            Exit Sub
        End If

        ' Monta o SQL de inserção
        sql = "INSERT INTO clientes (cnh, nome, data_nasc, cep, email, senha, telefone, status) VALUES (" &
      $"'{txt_cnh.Text.Replace("'", "''")}', " &
      $"'{txt_nome.Text.Replace("'", "''")}', " &
      $"'{dtp_nascimento.Value:yyyy-MM-dd}', " &
      $"'{txt_cep.Text.Replace("'", "''")}', " &
      $"'{txt_email.Text.Replace("'", "''")}', " &
      $"'{txt_senha.Text.Replace("'", "''")}', " &
      $"'{txt_fone.Text.Replace("'", "''")}', " &
      $"'ativo')"

        ' Executa o comando no banco
        db.Execute(sql)

        MsgBox("Cliente cadastrado com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        form1.Show()

        ' Limpa os campos
        txt_cnh.Clear()
        txt_nome.Clear()
        txt_email.Clear()
        txt_senha.Clear()
        txt_csenha.Clear()
        txt_fone.Clear()
        txt_cep.Clear()
        dtp_nascimento.Value = Date.Now
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        form1.Show()
    End Sub
End Class

