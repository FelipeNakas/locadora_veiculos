﻿Public Class Form3
    Private Sub btn_encerrar1_Click(sender As Object, e As EventArgs) Handles btn_encerrar1.Click
        form1.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form10.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form6.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form11.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Form12.Show()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs)
        Form7.Show
    End Sub
End Class