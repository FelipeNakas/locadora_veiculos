﻿Public Class Form9


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form8.Show()
        cmb_filtro3.Items.Clear()
        cmb_filtro3.Items.Add("Placa")
        cmb_filtro3.Items.Add("Marca")
        cmb_filtro3.Items.Add("Modelo")
        cmb_filtro3.SelectedIndex = 1
    End Sub

    Private Sub Form9_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        grid_veiculos()
        carregar_veiculos()
    End Sub

    '-----------------------------------------------------
    ' CARREGA VEÍCULOS DISPONÍVEIS
    '-----------------------------------------------------
    Sub carregar_veiculos()
        Try
            sql = "SELECT placa, marca, modelo, ano, cor, preco_diaria, foto " &
                  "FROM veiculos " &
                  "WHERE placa NOT IN (SELECT placa_veiculo FROM locacoes WHERE status='alugado')"

            rs = db.Execute(sql)
            dgv_veiculos.Rows.Clear()

            Do Until rs.EOF
                dgv_veiculos.Rows.Add(
                    rs.Fields("placa").Value,   ' ← fica oculta
                    rs.Fields("marca").Value,
                    rs.Fields("modelo").Value,
                    rs.Fields("ano").Value,
                    rs.Fields("cor").Value
                )
                rs.MoveNext()
            Loop

        Catch ex As Exception
            MsgBox("Erro ao carregar veículos: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    '-----------------------------------------------------
    ' CONFIGURA GRID
    '-----------------------------------------------------
    Sub grid_veiculos()
        dgv_veiculos.Columns.Clear()

        dgv_veiculos.Columns.Add("placa", "Placa")
        dgv_veiculos.Columns("placa").Visible = False   ' 👉 OCULTA A PLACA

        dgv_veiculos.Columns.Add("marca", "Marca")
        dgv_veiculos.Columns.Add("modelo", "Modelo")
        dgv_veiculos.Columns.Add("ano", "Ano")
        dgv_veiculos.Columns.Add("cor", "Cor")
    End Sub

    '-----------------------------------------------------
    ' CLIQUE NO GRID → CARREGA OS DADOS NOS CAMPOS
    '-----------------------------------------------------
    Private Sub dgv_veiculos_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_veiculos.CellContentClick
        Try
            If e.RowIndex < 0 Then Exit Sub

            ' Pega a placa oculta
            Dim placaSelecionada As String = dgv_veiculos.Rows(e.RowIndex).Cells("placa").Value.ToString()

            ' Busca dados completos no banco
            sql = "SELECT * FROM veiculos WHERE placa='" & placaSelecionada.Replace("'", "''") & "'"
            rs = db.Execute(sql)

            If Not rs.EOF Then
                txt_placa.Text = rs.Fields("placa").Value.ToString()
                txt_diaria.Text = rs.Fields("preco_diaria").Value.ToString()

            End If

        Catch ex As Exception
            MsgBox("Erro ao selecionar veículo: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub

    Private Sub ToolStripComboBox1_Click(sender As Object, e As EventArgs) Handles cmb_filtro3.Click

    End Sub

    Private Sub pic_veiculo_Click(sender As Object, e As EventArgs) Handles pic_veiculo.Click

    End Sub
End Class