﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(form1))
        txt_senha = New TextBox()
        txt_email = New TextBox()
        btn_entrar = New Button()
        chk_mostrar = New CheckBox()
        Label3 = New Label()
        LinkLabel1 = New LinkLabel()
        Label4 = New Label()
        Label1 = New Label()
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' txt_senha
        ' 
        txt_senha.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_senha.Location = New Point(791, 292)
        txt_senha.Margin = New Padding(2)
        txt_senha.Name = "txt_senha"
        txt_senha.Size = New Size(256, 27)
        txt_senha.TabIndex = 4
        ' 
        ' txt_email
        ' 
        txt_email.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_email.Location = New Point(791, 202)
        txt_email.Margin = New Padding(2)
        txt_email.Name = "txt_email"
        txt_email.Size = New Size(256, 27)
        txt_email.TabIndex = 5
        ' 
        ' btn_entrar
        ' 
        btn_entrar.BackColor = Color.IndianRed
        btn_entrar.ForeColor = Color.Black
        btn_entrar.Location = New Point(847, 457)
        btn_entrar.Margin = New Padding(2)
        btn_entrar.Name = "btn_entrar"
        btn_entrar.Size = New Size(142, 51)
        btn_entrar.TabIndex = 10
        btn_entrar.Text = "ENTRAR"
        btn_entrar.UseVisualStyleBackColor = False
        ' 
        ' chk_mostrar
        ' 
        chk_mostrar.AutoSize = True
        chk_mostrar.ForeColor = Color.IndianRed
        chk_mostrar.Location = New Point(791, 332)
        chk_mostrar.Margin = New Padding(2)
        chk_mostrar.Name = "chk_mostrar"
        chk_mostrar.Size = New Size(151, 24)
        chk_mostrar.TabIndex = 11
        chk_mostrar.Text = "MOSTRAR SENHA"
        chk_mostrar.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Perpetua Titling MT", 22.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label3.Location = New Point(849, 67)
        Label3.Name = "Label3"
        Label3.Size = New Size(140, 44)
        Label3.TabIndex = 15
        Label3.Text = "LOGIN"
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.AutoSize = True
        LinkLabel1.LinkColor = Color.Chocolate
        LinkLabel1.Location = New Point(861, 388)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(102, 20)
        LinkLabel1.TabIndex = 16
        LinkLabel1.TabStop = True
        LinkLabel1.Text = "CRIAR CONTA"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Perpetua Titling MT", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = Color.IndianRed
        Label4.Location = New Point(791, 183)
        Label4.Name = "Label4"
        Label4.Size = New Size(52, 17)
        Label4.TabIndex = 18
        Label4.Text = "EMAIL"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Perpetua Titling MT", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.IndianRed
        Label1.Location = New Point(791, 273)
        Label1.Name = "Label1"
        Label1.Size = New Size(57, 17)
        Label1.TabIndex = 19
        Label1.Text = "SENHA"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Location = New Point(2, -6)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(659, 565)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 17
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Coral
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(2, -6)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(659, 565)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 14
        PictureBox1.TabStop = False
        ' 
        ' form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(1145, 560)
        Controls.Add(Label1)
        Controls.Add(Label4)
        Controls.Add(PictureBox1)
        Controls.Add(PictureBox2)
        Controls.Add(LinkLabel1)
        Controls.Add(Label3)
        Controls.Add(chk_mostrar)
        Controls.Add(btn_entrar)
        Controls.Add(txt_email)
        Controls.Add(txt_senha)
        Margin = New Padding(2)
        Name = "form1"
        StartPosition = FormStartPosition.CenterScreen
        Text = "LOGIN"
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents txt_senha As TextBox
    Friend WithEvents txt_email As TextBox
    Friend WithEvents btn_entrar As Button
    Friend WithEvents chk_mostrar As CheckBox
    Friend WithEvents Label3 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox

End Class
