﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form9
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form9))
        ToolStrip1 = New ToolStrip()
        ToolStripLabel1 = New ToolStripLabel()
        ToolStripTextBox1 = New ToolStripTextBox()
        ToolStripLabel2 = New ToolStripLabel()
        cmb_filtro3 = New ToolStripComboBox()
        pic_veiculo = New PictureBox()
        txt_diaria = New TextBox()
        txt_placa = New MaskedTextBox()
        Label1 = New Label()
        Label2 = New Label()
        Button1 = New Button()
        Column4 = New DataGridViewTextBoxColumn()
        Column3 = New DataGridViewTextBoxColumn()
        Column2 = New DataGridViewTextBoxColumn()
        Column1 = New DataGridViewTextBoxColumn()
        dgv_veiculos = New DataGridView()
        ToolStrip1.SuspendLayout()
        CType(pic_veiculo, ComponentModel.ISupportInitialize).BeginInit()
        CType(dgv_veiculos, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' ToolStrip1
        ' 
        ToolStrip1.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        ToolStrip1.ImageScalingSize = New Size(24, 24)
        ToolStrip1.Items.AddRange(New ToolStripItem() {ToolStripLabel1, ToolStripTextBox1, ToolStripLabel2, cmb_filtro3})
        ToolStrip1.Location = New Point(0, 0)
        ToolStrip1.Name = "ToolStrip1"
        ToolStrip1.Size = New Size(1145, 28)
        ToolStrip1.TabIndex = 1
        ToolStrip1.Text = "ToolStrip1"
        ' 
        ' ToolStripLabel1
        ' 
        ToolStripLabel1.Font = New Font("Perpetua Titling MT", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        ToolStripLabel1.ForeColor = SystemColors.ControlLightLight
        ToolStripLabel1.Name = "ToolStripLabel1"
        ToolStripLabel1.Size = New Size(86, 25)
        ToolStripLabel1.Text = "PESQUISE:"
        ' 
        ' ToolStripTextBox1
        ' 
        ToolStripTextBox1.Name = "ToolStripTextBox1"
        ToolStripTextBox1.Size = New Size(81, 28)
        ' 
        ' ToolStripLabel2
        ' 
        ToolStripLabel2.Font = New Font("Perpetua Titling MT", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        ToolStripLabel2.ForeColor = SystemColors.ControlLightLight
        ToolStripLabel2.Name = "ToolStripLabel2"
        ToolStripLabel2.Size = New Size(116, 25)
        ToolStripLabel2.Text = "PARAMETRO:"
        ' 
        ' cmb_filtro3
        ' 
        cmb_filtro3.Name = "cmb_filtro3"
        cmb_filtro3.Size = New Size(98, 28)
        ' 
        ' pic_veiculo
        ' 
        pic_veiculo.BackColor = Color.White
        pic_veiculo.Image = CType(resources.GetObject("pic_veiculo.Image"), Image)
        pic_veiculo.Location = New Point(748, 108)
        pic_veiculo.Margin = New Padding(2)
        pic_veiculo.Name = "pic_veiculo"
        pic_veiculo.Size = New Size(226, 223)
        pic_veiculo.SizeMode = PictureBoxSizeMode.StretchImage
        pic_veiculo.TabIndex = 2
        pic_veiculo.TabStop = False
        ' 
        ' txt_diaria
        ' 
        txt_diaria.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_diaria.Location = New Point(921, 412)
        txt_diaria.Margin = New Padding(2)
        txt_diaria.Name = "txt_diaria"
        txt_diaria.Size = New Size(142, 27)
        txt_diaria.TabIndex = 4
        ' 
        ' txt_placa
        ' 
        txt_placa.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_placa.Location = New Point(659, 412)
        txt_placa.Margin = New Padding(2)
        txt_placa.Mask = "LLL_0000"
        txt_placa.Name = "txt_placa"
        txt_placa.Size = New Size(148, 27)
        txt_placa.TabIndex = 5
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.IndianRed
        Label1.ForeColor = SystemColors.ControlLightLight
        Label1.Location = New Point(921, 390)
        Label1.Margin = New Padding(2, 0, 2, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(105, 20)
        Label1.TabIndex = 6
        Label1.Text = "VALOR DIARIA"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.IndianRed
        Label2.ForeColor = SystemColors.ControlLightLight
        Label2.Location = New Point(659, 390)
        Label2.Margin = New Padding(2, 0, 2, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(53, 20)
        Label2.TabIndex = 7
        Label2.Text = "PLACA"
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Button1.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = Color.White
        Button1.Location = New Point(774, 479)
        Button1.Margin = New Padding(2)
        Button1.Name = "Button1"
        Button1.Size = New Size(183, 34)
        Button1.TabIndex = 69
        Button1.Text = "ALUGUE JÁ"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Column4
        ' 
        Column4.HeaderText = "Column4"
        Column4.MinimumWidth = 6
        Column4.Name = "Column4"
        Column4.ReadOnly = True
        Column4.Width = 125
        ' 
        ' Column3
        ' 
        Column3.HeaderText = "Column3"
        Column3.MinimumWidth = 6
        Column3.Name = "Column3"
        Column3.ReadOnly = True
        Column3.Width = 125
        ' 
        ' Column2
        ' 
        Column2.HeaderText = "Column2"
        Column2.MinimumWidth = 6
        Column2.Name = "Column2"
        Column2.ReadOnly = True
        Column2.Width = 125
        ' 
        ' Column1
        ' 
        Column1.HeaderText = "Column1"
        Column1.MinimumWidth = 6
        Column1.Name = "Column1"
        Column1.ReadOnly = True
        Column1.Width = 125
        ' 
        ' dgv_veiculos
        ' 
        dgv_veiculos.AllowUserToAddRows = False
        dgv_veiculos.AllowUserToDeleteRows = False
        dgv_veiculos.BackgroundColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        dgv_veiculos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgv_veiculos.Columns.AddRange(New DataGridViewColumn() {Column1, Column2, Column3, Column4})
        dgv_veiculos.Location = New Point(0, 30)
        dgv_veiculos.Margin = New Padding(2)
        dgv_veiculos.Name = "dgv_veiculos"
        dgv_veiculos.ReadOnly = True
        dgv_veiculos.RowHeadersWidth = 62
        dgv_veiculos.Size = New Size(599, 531)
        dgv_veiculos.TabIndex = 0
        ' 
        ' Form9
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(1145, 560)
        Controls.Add(Button1)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(txt_placa)
        Controls.Add(txt_diaria)
        Controls.Add(pic_veiculo)
        Controls.Add(ToolStrip1)
        Controls.Add(dgv_veiculos)
        Margin = New Padding(2)
        Name = "Form9"
        StartPosition = FormStartPosition.CenterScreen
        Text = "VÉICULOS"
        ToolStrip1.ResumeLayout(False)
        ToolStrip1.PerformLayout()
        CType(pic_veiculo, ComponentModel.ISupportInitialize).EndInit()
        CType(dgv_veiculos, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents ToolStripTextBox1 As ToolStripTextBox
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents cmb_filtro3 As ToolStripComboBox
    Friend WithEvents pic_veiculo As PictureBox
    Friend WithEvents txt_diaria As TextBox
    Friend WithEvents txt_placa As MaskedTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents dgv_veiculos As DataGridView
End Class
