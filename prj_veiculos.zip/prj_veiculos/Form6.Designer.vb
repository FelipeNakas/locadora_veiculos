﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form6))
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        Label9 = New Label()
        txt_placa = New MaskedTextBox()
        Label7 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        txt_cadastrar = New Button()
        Label1 = New Label()
        txt_cor = New TextBox()
        txt_modelo = New MaskedTextBox()
        txt_marca = New TextBox()
        txt_diaria = New TextBox()
        pic_veiculo = New PictureBox()
        btn_imagem = New Button()
        txt_ano = New TextBox()
        Label5 = New Label()
        OpenFileDialog1 = New OpenFileDialog()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(pic_veiculo, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), Image)
        PictureBox2.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox2.Location = New Point(1034, -4)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(110, 98)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 43
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox1.Location = New Point(-1, -4)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(134, 98)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 42
        PictureBox1.TabStop = False
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Perpetua Titling MT", 28.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label9.Location = New Point(277, 26)
        Label9.Name = "Label9"
        Label9.Size = New Size(605, 55)
        Label9.TabIndex = 41
        Label9.Text = "CADASTRO DE VEÍCULOS"
        ' 
        ' txt_placa
        ' 
        txt_placa.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_placa.Location = New Point(38, 211)
        txt_placa.Mask = "LLL0000"
        txt_placa.Name = "txt_placa"
        txt_placa.Size = New Size(165, 27)
        txt_placa.TabIndex = 37
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.BackColor = Color.FromArgb(CByte(192), CByte(64), CByte(0))
        Label7.Location = New Point(318, 321)
        Label7.Margin = New Padding(2, 0, 2, 0)
        Label7.Name = "Label7"
        Label7.Size = New Size(130, 20)
        Label7.TabIndex = 35
        Label7.Text = "VALOR DA DIÁRIA"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.FromArgb(CByte(192), CByte(64), CByte(0))
        Label4.Location = New Point(505, 321)
        Label4.Margin = New Padding(2, 0, 2, 0)
        Label4.Name = "Label4"
        Label4.Size = New Size(38, 20)
        Label4.TabIndex = 32
        Label4.Text = "COR"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.FromArgb(CByte(192), CByte(64), CByte(0))
        Label3.Location = New Point(483, 186)
        Label3.Margin = New Padding(2, 0, 2, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(60, 20)
        Label3.TabIndex = 31
        Label3.Text = "MARCA"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.FromArgb(CByte(192), CByte(64), CByte(0))
        Label2.Location = New Point(38, 186)
        Label2.Margin = New Padding(2, 0, 2, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(53, 20)
        Label2.TabIndex = 30
        Label2.Text = "PLACA"
        ' 
        ' txt_cadastrar
        ' 
        txt_cadastrar.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        txt_cadastrar.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        txt_cadastrar.ForeColor = Color.White
        txt_cadastrar.Location = New Point(461, 465)
        txt_cadastrar.Margin = New Padding(2)
        txt_cadastrar.Name = "txt_cadastrar"
        txt_cadastrar.Size = New Size(188, 50)
        txt_cadastrar.TabIndex = 29
        txt_cadastrar.Text = "CADASTRAR"
        txt_cadastrar.UseVisualStyleBackColor = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.FromArgb(CByte(192), CByte(64), CByte(0))
        Label1.Location = New Point(38, 321)
        Label1.Margin = New Padding(2, 0, 2, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(69, 20)
        Label1.TabIndex = 28
        Label1.Text = "MODELO"
        ' 
        ' txt_cor
        ' 
        txt_cor.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_cor.Location = New Point(496, 343)
        txt_cor.Margin = New Padding(2)
        txt_cor.Name = "txt_cor"
        txt_cor.Size = New Size(132, 27)
        txt_cor.TabIndex = 27
        ' 
        ' txt_modelo
        ' 
        txt_modelo.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_modelo.Location = New Point(38, 343)
        txt_modelo.Margin = New Padding(2)
        txt_modelo.Name = "txt_modelo"
        txt_modelo.Size = New Size(259, 27)
        txt_modelo.TabIndex = 25
        ' 
        ' txt_marca
        ' 
        txt_marca.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_marca.Location = New Point(484, 211)
        txt_marca.Margin = New Padding(2)
        txt_marca.Name = "txt_marca"
        txt_marca.Size = New Size(165, 27)
        txt_marca.TabIndex = 45
        ' 
        ' txt_diaria
        ' 
        txt_diaria.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_diaria.Location = New Point(318, 343)
        txt_diaria.Margin = New Padding(2)
        txt_diaria.Name = "txt_diaria"
        txt_diaria.Size = New Size(134, 27)
        txt_diaria.TabIndex = 46
        ' 
        ' pic_veiculo
        ' 
        pic_veiculo.BackColor = Color.Silver
        pic_veiculo.Location = New Point(733, 179)
        pic_veiculo.Margin = New Padding(2)
        pic_veiculo.Name = "pic_veiculo"
        pic_veiculo.Size = New Size(291, 217)
        pic_veiculo.SizeMode = PictureBoxSizeMode.StretchImage
        pic_veiculo.TabIndex = 47
        pic_veiculo.TabStop = False
        ' 
        ' btn_imagem
        ' 
        btn_imagem.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        btn_imagem.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btn_imagem.ForeColor = Color.White
        btn_imagem.Location = New Point(733, 179)
        btn_imagem.Margin = New Padding(2)
        btn_imagem.Name = "btn_imagem"
        btn_imagem.Size = New Size(33, 34)
        btn_imagem.TabIndex = 48
        btn_imagem.Text = "i"
        btn_imagem.UseVisualStyleBackColor = False
        ' 
        ' txt_ano
        ' 
        txt_ano.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_ano.Location = New Point(277, 211)
        txt_ano.Margin = New Padding(2)
        txt_ano.Name = "txt_ano"
        txt_ano.Size = New Size(132, 27)
        txt_ano.TabIndex = 49
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        Label5.Location = New Point(277, 186)
        Label5.Margin = New Padding(2, 0, 2, 0)
        Label5.Name = "Label5"
        Label5.Size = New Size(41, 20)
        Label5.TabIndex = 50
        Label5.Text = "ANO"
        ' 
        ' OpenFileDialog1
        ' 
        OpenFileDialog1.FileName = "OpenFileDialog1"
        ' 
        ' Form6
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(1145, 524)
        Controls.Add(Label5)
        Controls.Add(txt_ano)
        Controls.Add(btn_imagem)
        Controls.Add(pic_veiculo)
        Controls.Add(txt_diaria)
        Controls.Add(txt_marca)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Controls.Add(Label9)
        Controls.Add(txt_placa)
        Controls.Add(Label7)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(txt_cadastrar)
        Controls.Add(Label1)
        Controls.Add(txt_cor)
        Controls.Add(txt_modelo)
        ForeColor = SystemColors.ControlLightLight
        Name = "Form6"
        StartPosition = FormStartPosition.CenterScreen
        Text = "CADASTRO DE VEÍCULOS"
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(pic_veiculo, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txt_placa As MaskedTextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_cadastrar As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_cor As TextBox
    Friend WithEvents txt_modelo As MaskedTextBox
    Friend WithEvents txt_marca As TextBox
    Friend WithEvents txt_diaria As TextBox
    Friend WithEvents pic_veiculo As PictureBox
    Friend WithEvents btn_imagem As Button
    Friend WithEvents txt_ano As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
End Class
