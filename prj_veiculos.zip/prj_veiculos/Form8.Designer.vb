﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form8
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form8))
        Label9 = New Label()
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        txt_placa = New MaskedTextBox()
        cmb_pagamento = New ComboBox()
        dt_inicio = New DateTimePicker()
        GroupBox1 = New GroupBox()
        txt_diaria = New TextBox()
        txt_marca = New TextBox()
        Label12 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label1 = New Label()
        txt_modelo = New TextBox()
        GroupBox2 = New GroupBox()
        txt_email = New TextBox()
        txt_nome = New TextBox()
        txt_cnh = New MaskedTextBox()
        txt_fone = New MaskedTextBox()
        Label13 = New Label()
        Label6 = New Label()
        Label5 = New Label()
        Label2 = New Label()
        GroupBox3 = New GroupBox()
        dt_fim = New DateTimePicker()
        txt_final = New TextBox()
        Label14 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        Label11 = New Label()
        btn_alugar = New Button()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        GroupBox1.SuspendLayout()
        GroupBox2.SuspendLayout()
        GroupBox3.SuspendLayout()
        SuspendLayout()
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Perpetua Titling MT", 28.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label9.Location = New Point(432, 38)
        Label9.Name = "Label9"
        Label9.Size = New Size(262, 55)
        Label9.TabIndex = 42
        Label9.Text = "LOCAÇÃO"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), Image)
        PictureBox2.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox2.Location = New Point(2, 1)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(133, 124)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 59
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox1.Location = New Point(1010, 1)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(133, 124)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 60
        PictureBox1.TabStop = False
        ' 
        ' txt_placa
        ' 
        txt_placa.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_placa.Location = New Point(102, 38)
        txt_placa.Mask = "LLL0000"
        txt_placa.Name = "txt_placa"
        txt_placa.Size = New Size(153, 26)
        txt_placa.TabIndex = 61
        ' 
        ' cmb_pagamento
        ' 
        cmb_pagamento.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        cmb_pagamento.FormattingEnabled = True
        cmb_pagamento.Location = New Point(132, 128)
        cmb_pagamento.Name = "cmb_pagamento"
        cmb_pagamento.Size = New Size(133, 26)
        cmb_pagamento.TabIndex = 62
        ' 
        ' dt_inicio
        ' 
        dt_inicio.Format = DateTimePickerFormat.Short
        dt_inicio.Location = New Point(123, 32)
        dt_inicio.Name = "dt_inicio"
        dt_inicio.Size = New Size(153, 26)
        dt_inicio.TabIndex = 63
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(txt_diaria)
        GroupBox1.Controls.Add(txt_marca)
        GroupBox1.Controls.Add(Label12)
        GroupBox1.Controls.Add(Label4)
        GroupBox1.Controls.Add(txt_placa)
        GroupBox1.Controls.Add(Label3)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Controls.Add(txt_modelo)
        GroupBox1.Font = New Font("Perpetua Titling MT", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        GroupBox1.ForeColor = SystemColors.ActiveCaptionText
        GroupBox1.Location = New Point(103, 191)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(292, 221)
        GroupBox1.TabIndex = 64
        GroupBox1.TabStop = False
        GroupBox1.Text = "VEÍCULO"
        ' 
        ' txt_diaria
        ' 
        txt_diaria.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_diaria.Location = New Point(157, 170)
        txt_diaria.Name = "txt_diaria"
        txt_diaria.Size = New Size(111, 26)
        txt_diaria.TabIndex = 63
        ' 
        ' txt_marca
        ' 
        txt_marca.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_marca.Location = New Point(100, 128)
        txt_marca.Name = "txt_marca"
        txt_marca.Size = New Size(153, 26)
        txt_marca.TabIndex = 62
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.BackColor = Color.IndianRed
        Label12.ForeColor = SystemColors.Control
        Label12.Location = New Point(6, 173)
        Label12.Name = "Label12"
        Label12.Size = New Size(132, 18)
        Label12.TabIndex = 5
        Label12.Text = "Valor Diária:"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.IndianRed
        Label4.ForeColor = SystemColors.ButtonHighlight
        Label4.Location = New Point(6, 89)
        Label4.Name = "Label4"
        Label4.Size = New Size(82, 18)
        Label4.TabIndex = 4
        Label4.Text = "Modelo:"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.IndianRed
        Label3.ForeColor = SystemColors.ButtonHighlight
        Label3.Location = New Point(6, 130)
        Label3.Name = "Label3"
        Label3.Size = New Size(74, 18)
        Label3.TabIndex = 3
        Label3.Text = "Marca:"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.IndianRed
        Label1.ForeColor = SystemColors.ButtonHighlight
        Label1.Location = New Point(6, 45)
        Label1.Name = "Label1"
        Label1.Size = New Size(66, 18)
        Label1.TabIndex = 1
        Label1.Text = "Placa:"
        ' 
        ' txt_modelo
        ' 
        txt_modelo.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_modelo.Location = New Point(100, 82)
        txt_modelo.Name = "txt_modelo"
        txt_modelo.Size = New Size(153, 26)
        txt_modelo.TabIndex = 0
        ' 
        ' GroupBox2
        ' 
        GroupBox2.Controls.Add(txt_email)
        GroupBox2.Controls.Add(txt_nome)
        GroupBox2.Controls.Add(txt_cnh)
        GroupBox2.Controls.Add(txt_fone)
        GroupBox2.Controls.Add(Label13)
        GroupBox2.Controls.Add(Label6)
        GroupBox2.Controls.Add(Label5)
        GroupBox2.Controls.Add(Label2)
        GroupBox2.Font = New Font("Perpetua Titling MT", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        GroupBox2.ForeColor = SystemColors.ActiveCaptionText
        GroupBox2.Location = New Point(420, 191)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Size = New Size(284, 221)
        GroupBox2.TabIndex = 65
        GroupBox2.TabStop = False
        GroupBox2.Text = "CLIENTE"
        ' 
        ' txt_email
        ' 
        txt_email.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_email.Location = New Point(81, 158)
        txt_email.Name = "txt_email"
        txt_email.Size = New Size(153, 26)
        txt_email.TabIndex = 67
        ' 
        ' txt_nome
        ' 
        txt_nome.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_nome.Location = New Point(81, 73)
        txt_nome.Name = "txt_nome"
        txt_nome.Size = New Size(153, 26)
        txt_nome.TabIndex = 64
        ' 
        ' txt_cnh
        ' 
        txt_cnh.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_cnh.Location = New Point(81, 32)
        txt_cnh.Mask = "00000000000"
        txt_cnh.Name = "txt_cnh"
        txt_cnh.Size = New Size(153, 26)
        txt_cnh.TabIndex = 66
        ' 
        ' txt_fone
        ' 
        txt_fone.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_fone.Location = New Point(103, 116)
        txt_fone.Mask = "(99) 00000-0000"
        txt_fone.Name = "txt_fone"
        txt_fone.Size = New Size(153, 26)
        txt_fone.TabIndex = 62
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.BackColor = Color.IndianRed
        Label13.ForeColor = SystemColors.Control
        Label13.Location = New Point(6, 166)
        Label13.Name = "Label13"
        Label13.Size = New Size(62, 18)
        Label13.TabIndex = 65
        Label13.Text = "Email:"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.IndianRed
        Label6.ForeColor = SystemColors.Control
        Label6.Location = New Point(6, 76)
        Label6.Name = "Label6"
        Label6.Size = New Size(61, 18)
        Label6.TabIndex = 64
        Label6.Text = "Nome:"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.IndianRed
        Label5.ForeColor = SystemColors.ControlLightLight
        Label5.Location = New Point(6, 119)
        Label5.Name = "Label5"
        Label5.Size = New Size(91, 18)
        Label5.TabIndex = 63
        Label5.Text = "Telefone:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.IndianRed
        Label2.ForeColor = SystemColors.Control
        Label2.Location = New Point(6, 34)
        Label2.Name = "Label2"
        Label2.Size = New Size(49, 18)
        Label2.TabIndex = 2
        Label2.Text = "CNH:"
        ' 
        ' GroupBox3
        ' 
        GroupBox3.Controls.Add(dt_fim)
        GroupBox3.Controls.Add(txt_final)
        GroupBox3.Controls.Add(Label14)
        GroupBox3.Controls.Add(Label7)
        GroupBox3.Controls.Add(Label8)
        GroupBox3.Controls.Add(cmb_pagamento)
        GroupBox3.Controls.Add(Label11)
        GroupBox3.Controls.Add(dt_inicio)
        GroupBox3.Font = New Font("Perpetua Titling MT", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        GroupBox3.ForeColor = SystemColors.ActiveCaptionText
        GroupBox3.Location = New Point(724, 191)
        GroupBox3.Name = "GroupBox3"
        GroupBox3.Size = New Size(284, 221)
        GroupBox3.TabIndex = 66
        GroupBox3.TabStop = False
        GroupBox3.Text = "PAGAMENTO"
        ' 
        ' dt_fim
        ' 
        dt_fim.Format = DateTimePickerFormat.Short
        dt_fim.Location = New Point(123, 82)
        dt_fim.Name = "dt_fim"
        dt_fim.Size = New Size(153, 26)
        dt_fim.TabIndex = 71
        ' 
        ' txt_final
        ' 
        txt_final.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        txt_final.Location = New Point(132, 177)
        txt_final.Name = "txt_final"
        txt_final.Size = New Size(133, 26)
        txt_final.TabIndex = 70
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.BackColor = Color.IndianRed
        Label14.ForeColor = SystemColors.ButtonHighlight
        Label14.Location = New Point(6, 180)
        Label14.Name = "Label14"
        Label14.Size = New Size(120, 18)
        Label14.TabIndex = 69
        Label14.Text = "VALOR FINAL:"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.BackColor = Color.IndianRed
        Label7.ForeColor = SystemColors.ButtonHighlight
        Label7.Location = New Point(6, 136)
        Label7.Name = "Label7"
        Label7.Size = New Size(79, 18)
        Label7.TabIndex = 65
        Label7.Text = "METÓDO"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.BackColor = Color.IndianRed
        Label8.ForeColor = SystemColors.Control
        Label8.Location = New Point(6, 87)
        Label8.Name = "Label8"
        Label8.Size = New Size(92, 18)
        Label8.TabIndex = 66
        Label8.Text = "Data Fim:"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.BackColor = Color.IndianRed
        Label11.ForeColor = SystemColors.Control
        Label11.Location = New Point(6, 38)
        Label11.Name = "Label11"
        Label11.Size = New Size(111, 18)
        Label11.TabIndex = 68
        Label11.Text = "Data Início"
        ' 
        ' btn_alugar
        ' 
        btn_alugar.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        btn_alugar.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btn_alugar.ForeColor = Color.White
        btn_alugar.Location = New Point(484, 465)
        btn_alugar.Margin = New Padding(2)
        btn_alugar.Name = "btn_alugar"
        btn_alugar.Size = New Size(178, 51)
        btn_alugar.TabIndex = 63
        btn_alugar.Text = "ALUGAR"
        btn_alugar.UseVisualStyleBackColor = False
        ' 
        ' Form8
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(1145, 560)
        Controls.Add(btn_alugar)
        Controls.Add(GroupBox2)
        Controls.Add(GroupBox3)
        Controls.Add(GroupBox1)
        Controls.Add(PictureBox1)
        Controls.Add(PictureBox2)
        Controls.Add(Label9)
        Name = "Form8"
        StartPosition = FormStartPosition.CenterScreen
        Text = "LOCAÇÃO"
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        GroupBox2.ResumeLayout(False)
        GroupBox2.PerformLayout()
        GroupBox3.ResumeLayout(False)
        GroupBox3.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label9 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txt_placa As MaskedTextBox
    Friend WithEvents cmb_pagamento As ComboBox
    Friend WithEvents dt_inicio As DateTimePicker
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_modelo As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents btn_alugar As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents txt_cnh As MaskedTextBox
    Friend WithEvents txt_fone As MaskedTextBox
    Friend WithEvents txt_diaria As TextBox
    Friend WithEvents txt_marca As TextBox
    Friend WithEvents txt_email As TextBox
    Friend WithEvents txt_nome As TextBox
    Friend WithEvents txt_final As TextBox
    Friend WithEvents dt_fim As DateTimePicker
End Class
