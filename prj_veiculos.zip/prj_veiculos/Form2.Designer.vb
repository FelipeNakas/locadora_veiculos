﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        btn_encerrar = New Button()
        btn_dados = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Label9 = New Label()
        PictureBox2 = New PictureBox()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' btn_encerrar
        ' 
        btn_encerrar.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        btn_encerrar.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btn_encerrar.Location = New Point(858, 450)
        btn_encerrar.Margin = New Padding(2)
        btn_encerrar.Name = "btn_encerrar"
        btn_encerrar.Size = New Size(243, 65)
        btn_encerrar.TabIndex = 11
        btn_encerrar.Text = "ENCERRAR"
        btn_encerrar.UseVisualStyleBackColor = False
        ' 
        ' btn_dados
        ' 
        btn_dados.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        btn_dados.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btn_dados.ForeColor = SystemColors.ControlLightLight
        btn_dados.Location = New Point(573, 450)
        btn_dados.Margin = New Padding(2)
        btn_dados.Name = "btn_dados"
        btn_dados.Size = New Size(213, 65)
        btn_dados.TabIndex = 12
        btn_dados.Text = "MEUS DADOS"
        btn_dados.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Button2.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button2.Location = New Point(303, 450)
        Button2.Margin = New Padding(2)
        Button2.Name = "Button2"
        Button2.Size = New Size(208, 65)
        Button2.TabIndex = 13
        Button2.Text = "VEÍCULOS"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Button3.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button3.ForeColor = Color.White
        Button3.Location = New Point(28, 450)
        Button3.Margin = New Padding(2)
        Button3.Name = "Button3"
        Button3.Size = New Size(208, 65)
        Button3.TabIndex = 14
        Button3.Text = "LOCAÇÃO "
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Palatino Linotype", 28.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.ForeColor = Color.FromArgb(CByte(255), CByte(128), CByte(0))
        Label9.Location = New Point(498, 50)
        Label9.Name = "Label9"
        Label9.Size = New Size(176, 63)
        Label9.TabIndex = 22
        Label9.Text = "MENU"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(388, 82)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(386, 369)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 26
        PictureBox2.TabStop = False
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(1145, 560)
        Controls.Add(Label9)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(btn_dados)
        Controls.Add(btn_encerrar)
        Controls.Add(PictureBox2)
        ForeColor = SystemColors.ControlLightLight
        Margin = New Padding(2)
        Name = "Form2"
        StartPosition = FormStartPosition.CenterScreen
        Text = "MENU "
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents btn_encerrar As Button
    Friend WithEvents btn_dados As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents PictureBox2 As PictureBox
End Class
